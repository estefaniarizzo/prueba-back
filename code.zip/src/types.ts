export interface ApiResponseSuccess {
  date: string;
}

export interface ApiResponseError {
  error: string;
  message: string;
}
